# YATAYAT SERVICE – By VAHAN CUSTOMER

This is an installable PWA demo that works on Android/iOS browsers and can be added to the home screen.

Included:
- YATAYAT SERVICE UI + logo
- Customer mobile/OTP flow (demo OTP: 123456)
- Service selection
- Customer/application form
- Document upload UI
- Payment flow (demo)
- Application tracking
- Admin login/dashboard
- Status management

Important: this version stores demo data in the browser's localStorage. It is NOT suitable for storing real Aadhaar/DL/RC documents or real payments. Before production, connect a secure backend, private encrypted object storage, real OTP provider, proper authentication/roles, audit logs, and a compliant payment gateway. Verify current government/RTO requirements through official sources.

To run:
1. Serve this folder over HTTP/HTTPS (for example with VS Code Live Server or `python -m http.server`).
2. Open index.html in Chrome/Safari.
3. Use "Add to Home Screen" / "Install App".

Demo admin: admin / ChangeMe123!
Demo OTP: 123456
