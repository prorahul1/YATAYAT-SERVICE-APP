# YATAYAT SERVICE APP V4
Secure-document workflow starter.

## Run
1. `npm install`
2. `cp .env.example .env`
3. Edit `.env`: set a strong SESSION_SECRET and a NEW admin password.
4. `npm start`
5. Forward port 8080 privately.

## Security model
Uploaded files are stored in `private_uploads/`, not `public/`. Customers can see their application status but there is no customer document-download endpoint. Document metadata and downloads require server-side admin authorization.

## Production requirements
This is a starter, not a compliance-certified production service. Before real Aadhaar/DL/RC or similar sensitive documents:
- HTTPS and secure cookies
- production session store
- real SMS OTP provider
- encrypted private object storage
- CSRF protection and audit logs
- retention/deletion policy and privacy policy
- proper payment gateway server integration
- Google Play Data Safety disclosures
- rotate all development/admin credentials
